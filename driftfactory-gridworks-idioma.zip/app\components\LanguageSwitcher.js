"use client";

import { usePathname } from "next/navigation";
import { setLocale } from "../actions/locale";

const LANGS = [
  { code: "pt", label: "PT", flag: "🇵🇹" },
  { code: "en", label: "EN", flag: "🇬🇧" },
  { code: "es", label: "ES", flag: "🇪🇸" },
  { code: "fr", label: "FR", flag: "🇫🇷" },
];

export default function LanguageSwitcher({ current, compact }) {
  const pathname = usePathname();

  return (
    <form action={setLocale} className={`lang-switcher${compact ? " compact" : ""}`}>
      <input type="hidden" name="path" value={pathname} />
      <select
        name="locale"
        defaultValue={current}
        aria-label="Idioma / Language"
        onChange={(e) => e.target.form.requestSubmit()}
      >
        {LANGS.map((l) => (
          <option key={l.code} value={l.code}>
            {l.flag} {l.label}
          </option>
        ))}
      </select>
    </form>
  );
}
