import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "../../../lib/db";
import { productToView } from "../../../lib/transform";
import IconGlyph from "../../../components/IconGlyph";
import ProductDetailActions from "../../../components/ProductDetailActions";
import { PRODUCT_ICONS } from "../../../lib/icons";
import { getLocale } from "../../../lib/i18n";

export async function generateMetadata({ params }) {
  const { id } = await params;
  const row = await prisma.product.findUnique({ where: { id: Number(id) } });
  if (!row) return { title: "Produto — Drift Factory" };
  return {
    title: `${row.name} — Loja Drift Factory`,
    description: row.description || `${row.name} na loja oficial Drift Factory.`,
  };
}

export default async function ProductPage({ params }) {
  const locale = await getLocale();
  const { id } = await params;
  const row = await prisma.product.findUnique({ where: { id: Number(id) } });
  if (!row) notFound();
  const product = productToView(row, locale);

  return (
    <section className="section">
      <div className="container">
        <div className="breadcrumb"><Link href="/">Início</Link> / <Link href="/loja">Loja</Link> / {product.name}</div>

        <div className="product-detail">
          <div className={`product-detail-media ${product.grad}`}>
            {product.imageUrl ? (
              <img src={product.imageUrl} alt={product.name} />
            ) : (
              <IconGlyph recipe={PRODUCT_ICONS[product.icon] || PRODUCT_ICONS.shirt} color={product.colorVar} />
            )}
          </div>

          <div>
            <span className="eyebrow">{product.cats[0] || "Merch"}</span>
            <h1 className="display h2" style={{ marginTop: ".6rem" }}>{product.name}</h1>

            <div className="product-detail-price">
              {product.oldPrice && <span className="product-old">{product.oldPrice.toFixed(2)} €</span>}
              <span className="product-price">{product.price.toFixed(2)} €</span>
            </div>

            {product.description && <p className="lede" style={{ marginBottom: "1.6rem" }}>{product.description}</p>}

            <ProductDetailActions product={product} />

            <div className="stock-status">
              <span className={`stock-dot${product.inStock ? "" : " out"}`} />
              {product.inStock ? "Em stock, pronto a enviar" : "Esgotado — volta em breve"}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
