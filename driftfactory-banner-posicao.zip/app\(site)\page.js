import Link from "next/link";
import Countdown from "../components/Countdown";
import NewsletterForm from "../components/NewsletterForm";
import DriverCard from "../components/DriverCard";
import IconGlyph from "../components/IconGlyph";
import { prisma } from "../lib/db";
import { driverToView, newsToView } from "../lib/transform";
import { NEWS_ICONS } from "../lib/icons";

export default async function HomePage() {
  const [newsRows, champs, driverRows, events, driverCount, banners] = await Promise.all([
    prisma.newsArticle.findMany({ orderBy: { publishedAt: "desc" }, take: 5 }),
    prisma.championship.findMany({ orderBy: { id: "asc" }, take: 4 }),
    prisma.driver.findMany({ orderBy: { standing: "asc" }, take: 4 }),
    prisma.calendarEvent.findMany({ orderBy: { fullDate: "asc" } }),
    prisma.driver.count(),
    prisma.banner.findMany({ where: { slot: { in: ["home_hero", "home_virtual"] } }, orderBy: { updatedAt: "desc" } }),
  ]);

  const heroBanner = banners.find((b) => b.slot === "home_hero");
  const virtualBanner = banners.find((b) => b.slot === "home_virtual");

  const news = newsRows.map(newsToView);
  const drivers = driverRows.map(driverToView);
  const featuredNews = news.slice(0, 3);
  const ticker = news.length > 0 ? news.map((n) => `${n.badge} — ${n.title}`) : ["Bem-vindo à Drift Factory"];

  const nextEvent =
    events.find((e) => e.status === "live") ||
    events.find((e) => new Date(e.fullDate) > new Date()) ||
    events[events.length - 1];

  return (
    <>
      <div className="ticker-bar">
        <div className="ticker-track">
          {[...ticker, ...ticker].map((t, i) => (
            <span key={i}>{t}</span>
          ))}
        </div>
      </div>

      <section
        className={`hero${heroBanner ? " hero-has-photo" : ""}`}
        style={heroBanner ? { backgroundImage: `url(${heroBanner.imageUrl})`, backgroundPosition: heroBanner.position } : undefined}
      >
        {heroBanner && <div className="hero-scrim" />}
        <div className="container hero-inner">
          <div className="hero-copy">
            <span className="eyebrow">Portugal · Europa · Drift</span>
            <h1 className="display h1">
              A fábrica
              <br />
              do <span className="text-gradient">drift</span>
              <br />
              português.
            </h1>
            <p className="lede">
              Notícias, campeonatos, pilotos e resultados — tudo o que precisas
              para acompanhar a cena do drift em Portugal e no resto da
              Europa, num só sítio.
            </p>
            <div className="hero-actions">
              <Link href="/noticias" className="btn btn-lime">Ver notícias</Link>
              <Link href="/campeonatos" className="btn btn-outline">Campeonatos</Link>
            </div>
            <div className="hero-stats">
              <div className="hero-stat"><b>{champs.length}</b><span>Campeonatos seguidos</span></div>
              <div className="hero-stat"><b>{driverCount}</b><span>Pilotos catalogados</span></div>
              <div className="hero-stat"><b>{events.length}</b><span>Eventos por época</span></div>
            </div>
          </div>

          {!heroBanner && (
            <div className="hero-visual">
              <div className="hero-frame">
                <svg viewBox="0 0 200 200" fill="none" stroke="var(--lime)" strokeWidth="2.4">
                  <circle cx="100" cy="100" r="70" stroke="var(--line)" />
                  <circle cx="100" cy="100" r="70" strokeDasharray="6 10" stroke="var(--pink)" opacity=".6" />
                  <path d="M40 128 C 60 70, 140 70, 160 128" />
                  <circle cx="62" cy="132" r="14" />
                  <circle cx="140" cy="132" r="14" />
                  <path d="M60 100 L 100 60 L 150 100" stroke="var(--pink)" />
                </svg>
                <span className="tag">Época 2026</span>
              </div>
              <svg className="corner-flag" viewBox="0 0 40 40">
                <g fill="var(--text)">
                  <rect x="0" y="0" width="10" height="10" /><rect x="20" y="0" width="10" height="10" />
                  <rect x="10" y="10" width="10" height="10" /><rect x="30" y="10" width="10" height="10" />
                  <rect x="0" y="20" width="10" height="10" /><rect x="20" y="20" width="10" height="10" />
                  <rect x="10" y="30" width="10" height="10" /><rect x="30" y="30" width="10" height="10" />
                </g>
              </svg>
            </div>
          )}
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-head">
            <div>
              <span className="eyebrow">Últimas</span>
              <h2 className="display h2">Notícias em destaque</h2>
            </div>
            <Link href="/noticias" className="btn btn-outline btn-sm">Todas as notícias</Link>
          </div>

          {featuredNews.length === 0 ? (
            <p className="lede">Ainda não há notícias publicadas.</p>
          ) : (
            <div className="grid grid-3">
              {featuredNews.map((n) => (
                <article className="card" key={n.id}>
                  <div className={`card-media ${n.grad}`}>
                    <span className={`badge${n.badgePink ? " pink" : ""}`}>{n.badge}</span>
                    {n.imageUrl ? (
                      <img src={n.imageUrl} alt="" />
                    ) : (
                      <IconGlyph recipe={NEWS_ICONS[n.icon] || NEWS_ICONS.target} />
                    )}
                  </div>
                  <div className="card-body">
                    <div className="card-meta"><span>{n.badge}</span><span>·</span><span>{n.dateLabel}</span></div>
                    <h3 className="card-title">{n.title}</h3>
                    <p className="card-excerpt">{n.excerpt}</p>
                    <Link href="/noticias" className="card-link">Ler notícia</Link>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="section section-alt">
        <div className="container">
          <div className="section-head">
            <div>
              <span className="eyebrow pink">Séries</span>
              <h2 className="display h2">Campeonatos que seguimos</h2>
            </div>
            <Link href="/campeonatos" className="btn btn-outline btn-sm">Ver todos</Link>
          </div>

          {champs.length === 0 ? (
            <p className="lede">Ainda não há campeonatos registados.</p>
          ) : (
            <div className="grid grid-4">
              {champs.map((c) => (
                <div className="champ-card" data-code={c.code} key={c.code}>
                  <span className="champ-code">{c.code}</span>
                  <span className="champ-name">{c.name}</span>
                  <p className="champ-desc">{c.desc}</p>
                  <div className="champ-foot"><span>{c.rounds} rondas</span><span>2026</span></div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {nextEvent && (
        <section className="section">
          <div className="container">
            <div className="cta-band">
              <div>
                <span className="eyebrow">Próximo evento</span>
                <h2 className="h3" style={{ marginTop: ".5rem", fontFamily: "var(--font-head)", textTransform: "uppercase" }}>
                  {nextEvent.title}
                </h2>
                <p className="lede" style={{ marginTop: ".5rem" }}>{nextEvent.desc}</p>
              </div>
              <Countdown target={nextEvent.fullDate.toISOString()} />
              <Link href="/calendario" className="btn btn-lime">Ver calendário</Link>
            </div>
          </div>
        </section>
      )}

      <section
        className={`section section-alt${virtualBanner ? " section-has-photo" : ""}`}
        style={virtualBanner ? { backgroundImage: `url(${virtualBanner.imageUrl})`, backgroundPosition: virtualBanner.position } : undefined}
      >
        {virtualBanner && <div className="hero-scrim" />}
        <div className="container hero-inner" style={{ gridTemplateColumns: ".9fr 1.1fr" }}>
          {!virtualBanner && (
            <div className="hero-visual" style={{ order: 2 }}>
              <div className="hero-frame">
                <svg viewBox="0 0 200 200" fill="none" stroke="var(--pink)" strokeWidth="2.4">
                  <rect x="40" y="40" width="120" height="120" rx="16" stroke="var(--line)" />
                  <path d="M70 130 L100 70 L130 130 M85 130 L100 100 L115 130" />
                  <circle cx="100" cy="100" r="46" strokeDasharray="4 8" opacity=".5" />
                </svg>
                <span className="tag">Sexta 21h00</span>
              </div>
            </div>
          )}
          <div className="hero-copy" style={{ order: 1 }}>
            <span className="eyebrow pink">Sim racing</span>
            <h2 className="display h2">Drift Virtual: a liga que nunca fecha o autódromo</h2>
            <p className="lede">Junta-te à comunidade que compete em Assetto Corsa e CarX — leaderboards semanais, eventos ao vivo e um Discord sempre ativo.</p>
            <Link href="/drift-virtual" className="btn btn-pink">Entrar na liga</Link>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-head">
            <div>
              <span className="eyebrow">Grelha</span>
              <h2 className="display h2">Pilotos em destaque</h2>
            </div>
            <Link href="/pilotos" className="btn btn-outline btn-sm">Ver todos os pilotos</Link>
          </div>
          {drivers.length === 0 ? (
            <p className="lede">Ainda não há pilotos registados.</p>
          ) : (
            <div className="grid grid-4">
              {drivers.map((d) => (
                <DriverCard driver={d} key={d.slug} />
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="section section-alt">
        <div className="container">
          <div className="footer-newsletter" style={{ maxWidth: 640, margin: "0 auto", textAlign: "center" }}>
            <span className="eyebrow" style={{ justifyContent: "center" }}>Newsletter</span>
            <h2 className="display h2" style={{ marginTop: ".6rem" }}>Fica na zona.</h2>
            <p className="lede" style={{ margin: ".8rem auto 1.4rem" }}>Sê o primeiro a saber o que se passa no mundo do drift — direto na tua caixa de correio.</p>
            <NewsletterForm center />
          </div>
        </div>
      </section>
    </>
  );
}
