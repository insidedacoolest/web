import { PRODUCT_ICON_KEYS } from "../../lib/icons";

export default function ProductForm({ action, initial, submitLabel }) {
  return (
    <form action={action} className="admin-form">
      <label className="admin-field">
        <span>Foto do produto</span>
        {initial?.imageUrl && (
          <img src={initial.imageUrl} alt="" className="admin-image-preview" />
        )}
        <input type="file" name="image" accept="image/*" />
        <span className="admin-hint">JPG, PNG ou WEBP, até 20MB. Deixa em branco para manter a foto atual e usar o ícone.</span>
      </label>

      <label className="admin-field">
        <span>Nome do produto</span>
        <input type="text" name="name" required defaultValue={initial?.name} />
      </label>

      <label className="admin-field">
        <span>Descrição</span>
        <textarea name="description" defaultValue={initial?.description} />
      </label>

      <div className="admin-form-row">
        <label className="admin-field">
          <span>Preço (€)</span>
          <input type="number" step="0.01" name="price" required defaultValue={initial?.price} />
        </label>
        <label className="admin-field">
          <span>Preço antigo (opcional, para promoção)</span>
          <input type="number" step="0.01" name="oldPrice" defaultValue={initial?.oldPrice ?? ""} />
        </label>
      </div>

      <label className="admin-field">
        <span>Categoria (separadas por vírgula)</span>
        <input type="text" name="cats" required placeholder="vestuario" defaultValue={initial?.catsCsv} />
        <span className="admin-hint">Usa: vestuario, acessorios, colecionaveis</span>
      </label>

      <label className="admin-field">
        <span>Tamanhos (opcional, separados por vírgula)</span>
        <input type="text" name="sizes" placeholder="S,M,L,XL,2XL" defaultValue={initial?.sizesCsv || ""} />
        <span className="admin-hint">Deixa em branco para produtos sem tamanho (acessórios, colecionáveis).</span>
      </label>

      <label className="admin-field admin-checkbox">
        <input type="checkbox" name="inStock" defaultChecked={initial ? initial.inStock : true} />
        <span>Em stock (disponível para compra)</span>
      </label>

      <div className="admin-form-row">
        <label className="admin-field">
          <span>Ícone</span>
          <select name="icon" defaultValue={initial?.icon || "shirt"}>
            {PRODUCT_ICON_KEYS.map((k) => <option key={k} value={k}>{k}</option>)}
          </select>
        </label>
        <label className="admin-field">
          <span>Cor</span>
          <select name="color" defaultValue={initial?.color || "lime"}>
            <option value="lime">Lima</option>
            <option value="pink">Rosa</option>
          </select>
        </label>
      </div>

      <label className="admin-field">
        <span>Fundo do cartão (1-4)</span>
        <select name="grad" defaultValue={initial?.grad || 1}>
          <option value={1}>1</option>
          <option value={2}>2</option>
          <option value={3}>3</option>
          <option value={4}>4</option>
        </select>
      </label>

      <div className="admin-form-actions">
        <button type="submit" className="btn btn-lime">{submitLabel}</button>
      </div>
    </form>
  );
}
